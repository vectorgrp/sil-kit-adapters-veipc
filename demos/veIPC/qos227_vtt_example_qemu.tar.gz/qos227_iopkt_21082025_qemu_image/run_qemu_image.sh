#!/bin/bash

command -v qemu-system-x86_64 >/dev/null 2>&1 || { echo >&2 "qemu-system-x86_64 doesn't exist. Please install qemu-kvm. Aborting."; exit 1; }

# Current directory
script_dir=$(pwd)

# Check if script is being run from the correct folder (qemu image folder)
if [[ ! -f "$script_dir/output/disk-qemu.vmdk" ]]; then
    echo -e "\033[1m\033[31mError: run_qemu_image.sh must be run from the qemu image folder.\033[0m"
    exit 1
fi

first_macaddr=$(echo 00:60:2F:$[RANDOM%10]$[RANDOM%10]:$[RANDOM%10]$[RANDOM%10]:$[RANDOM%10]$[RANDOM%10])
second_macaddr=$(echo 00:60:2F:$[RANDOM%10]$[RANDOM%10]:$[RANDOM%10]$[RANDOM%10]:$[RANDOM%10]$[RANDOM%10])

while [ "$second_macaddr" = "$first_macaddr" ]
do
  # Generate new mac address
  second_macaddr=$(echo 00:60:2F:$[RANDOM%10]$[RANDOM%10]:$[RANDOM%10]$[RANDOM%10]:$[RANDOM%10]$[RANDOM%10])
done

echo "First assigned MAC address : $first_macaddr"
echo "Second assigned MAC address : $second_macaddr"

# Run a dummy sudo command to prompt for the password
sudo -v
# Check if sudo command was successful
if [ $? -ne 0 ]; then
  echo -e "Failed to obtain sudo privileges. Exiting."
  exit 1
fi

if [[ ! -z $(kvm-ok | grep "Your CPU does not support KVM extensions") ]]; then
    echo -e "\e[0;33mWarning: KVM is not supported. Check hardware virtualization if enabled.\e[0m"
    echo -e "\e[0;33mWarning: QEMU image will run but test exeuction will be very slow...\e[0m"
    accel_options=()
else 
    echo "KVM is enabled."
    sudo chown $USER:kvm /dev/kvm
    accel_options=(-accel kvm)
fi

qemu_command=(qemu-system-x86_64 ${accel_options[@]} -smp 2 -m 1G -drive file=output/disk-qemu.vmdk,if=ide,id=drv0 -netdev bridge,br=br0,id=net0 -device e1000,netdev=net0,mac=$first_macaddr -netdev bridge,br=br0,id=net1 -device e1000,netdev=net1,mac=$second_macaddr -pidfile output/qemu.pid -nographic -kernel output/ifs.bin -serial file:output/qemu.out -object rng-random,filename=/dev/urandom,id=rng0 -device virtio-rng-pci,rng=rng0)

echo "Executing qemu command .. "
${qemu_command[@]} >/dev/null </dev/null &
